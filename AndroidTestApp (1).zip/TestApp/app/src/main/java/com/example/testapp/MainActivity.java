package com.example.testapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.widget.*;
import android.os.Bundle;
import java.util.Random;
import android.view.View;

import java.util.ArrayList;
//Over view: chess board gui is just 64 ImageButtons and their IDs follow their index values
// button_12 is Board[2][1], button_36 is Board[6][3] etc
public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private ChessBoard BOARD = new ChessBoard();
    private String Selected_PieceString= null; //string of id of first mouse click
    Coordinates start = null;
    Coordinates end = null;
    private TextView textDisplay; //just single line of text that shows game status, could be interchanged with alerts
    //if we wanna make it cleaner later on
    private ImageButton[][] buttons = new ImageButton[8][8]; //
    ArrayList<ChessBoard> RECORD = new ArrayList<ChessBoard>(); //arraylist of chessboard objects used to save game moves
    ChessBoard prev = new ChessBoard(); //i use chessboard copy method to copy the board into this before everywhere
    //the undo button replaced the current board with prev board.




    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textDisplay = findViewById(R.id.textDisplay);
        RECORD.add(prev);
        for(int i = 0; i<8;i++) {  //saves all the button ids into 8x8 array
            for (int j = 0; j < 8; j++) {
                String buttonID = "button_" + i + j;
                int resID = getResources().getIdentifier(buttonID, "id", getPackageName());
                //System.out.println(resID+"Ffuck" + buttonID);
                buttons[i][j] =findViewById(resID);

                buttons[i][j].setOnClickListener(this); //

            }
        }


       ImageButton buttonUNDO = findViewById(R.id.UNDO);
       buttonUNDO.setOnClickListener(this);

       ImageButton buttonRESIGN = findViewById(R.id.RESIGN);
       buttonRESIGN.setOnClickListener(this);

       ImageButton buttonDRAW= findViewById(R.id.DRAW);
        buttonDRAW.setOnClickListener(this);

        ImageButton buttonAI = findViewById(R.id.AI);
        buttonAI.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        int x;
        int y;
        String idString = v.getResources().getResourceEntryName(v.getId()); //converts ID into string
        System.out.println(" idString is: " + idString);
        if (idString.equals("UNDO")) {  //if else statements to perform different actions based on button
            System.out.println("UNDOOOO");
            BOARD = prev;  //undos last move
            RECORD.remove(RECORD.size()-1);
            refreshBoard(); //refreshes Chess gui

        } else if (idString.equals("RESIGN")) { //still need to implement way to exit screen once game ends
            BOARD.CHECKMATE = true;             // and offer to save the game
            if (BOARD.TURN.equals("White's "))
                textDisplay.setText("Checkmate!: Black wins");
            else
                textDisplay.setText("Checkmate!: White wins");

            refreshBoard();
        } else if (idString.equals("DRAW")) { //draw button
            textDisplay.setText("Stalemate!");
            Intent myIntent = new Intent(MainActivity.this, SaveGameActivity.class);
            myIntent.putExtra("key", RECORD); //Optional parameters
            MainActivity.this.startActivity(myIntent);

        } else if (idString.equals("AI")) {  //AI button
            int x1=-1;
            int y1=-1;
            ArrayList<Coordinates> moves = new ArrayList<>();
            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 8; j++) {
                    //traverses through array to find first piece that belongs to current turn

                    if (BOARD.Board[i][j].isEmpty) {
                        continue;
                    }
                    if ((BOARD.TURN.equals("White's ") && BOARD.Board[i][j].piece.charAt(0) == 'w')
                            || (BOARD.TURN.equals("Black's ") && BOARD.Board[i][j].piece.charAt(0) == 'b')) {
                        moves = BOARD.Possible_Moves(BOARD.Board[i][j]); //Possible_Moves returns arraylist of all moves for a piece

                        if (moves.size() == 0)
                            continue;
                        else {    //saves index values into x1 and y1 to survive the instance
                            x1 = j;
                            y1 = i;
                            i=9; j =9;
                            break;
                        }
                    }
                }
            }
            if (x1 != -1 && y1 != -1) {
                Random rand = new Random();  //
                int n = rand.nextInt(moves.size());
                x = moves.get(n).x;  // finds random move for that piece
                y = moves.get(n).y;
                prev = BOARD.copy(BOARD); //saves board into prev
                BOARD.Move(new Coordinates(x1, y1), new Coordinates(x, y)); //conducts that move
                RECORD.add(BOARD.copy(BOARD));

                BOARD.Analyze(); //checks for check/checkmate/stalemate
                BOARD.Stalemated();
                BOARD.Checkmated();
                refreshBoard(); //modifies GUI
                start = null;
                end = null;
                Selected_PieceString = null; //resets mouse click to no button
            }
        }

            else if (Selected_PieceString != null) {//check if piece has already been chosen
                //does this code if a button is already selected
                System.out.println("Piece chosen already, new piece chose:  " + idString);
                x = idString.charAt(8) - '0';
                y = idString.charAt(7) - '0';
                end = new Coordinates(x, y); //saves coordinates of chosen piece
                if (BOARD.Search_Moves(start, end) != -1) {
                    prev = BOARD.copy(BOARD);
                    BOARD.Move(start, end);  //makes move on board
                    RECORD.add(BOARD.copy(BOARD));
                    BOARD.Analyze();
                    BOARD.Stalemated();
                    BOARD.Checkmated();

                } else {
                    System.out.println("Error invalid move"); //error statement if move illegal
                    textDisplay.setText("Error Invalid Move");
                    //insert alert
                }                       //if move is illegal, first click and chosen squares are all reset
                start = null;
                end = null;
                Selected_PieceString = null;
                //BOARD.printBoard();
                refreshBoard();
                return;
            }
                else { //does this code if no piece has been chosen
                System.out.println("IDStriNG: " + idString);
                Selected_PieceString = idString;
                x = idString.charAt(8) - '0';
                y = idString.charAt(7) - '0'; //converts char to int
                if (BOARD.Board[y][x].isEmpty) {  //returns if user clicks on empty piece
                    Selected_PieceString = null;
                    return;
                }

                //error statements if its whites turn, and a blck piece is chosen first

                if (BOARD.TURN.equals("White's ") && BOARD.Board[y][x].piece.charAt(0) != 'w') {
                    textDisplay.setText("Error: White's Turn");
                    start = null;
                    end = null;
                    Selected_PieceString = null;
                    return;
                }
                if (BOARD.TURN.equals("Black's ") && BOARD.Board[y][x].piece.charAt(0) != 'b') {
                    textDisplay.setText("Error: Black's Turn");
                    start = null;
                    end = null;
                    Selected_PieceString = null;
                    return;
                }

                System.out.println(x + "<->" + y);
                start = new Coordinates(x, y);
                return;
            }
    }

    public void refreshBoard(){ //traverses through ChessBoard object and updates gui counterparts by
        // changing their image, images follow name pattern where
        // drawable.bpb means black pawn on shaded spot, wKw means white king on white spot

        for(int i=0;i<8;i++){ //promotion
            if (!BOARD.Board[0][i].isEmpty) {
                if (BOARD.Board[0][i].piece.equals("wp"))
                    BOARD.Board[0][i].piece = "wQ";
            }
            if (!BOARD.Board[7][i].isEmpty) {
                if (BOARD.Board[7][i].piece.equals("bp"))
                    BOARD.Board[7][i].piece = "bQ";
            }
        }


        for (int i =0; i<8;i++){
            for (int j=0; j<8;j++){

                if (BOARD.Board[i][j].isEmpty){
                    if(BOARD.Board[i][j].color == 'b')
                    buttons[i][j].setImageResource(R.drawable.blackspace);
                    else
                        buttons[i][j].setImageResource(R.drawable.whitespace);
                }
                else{
                    //if not whitespace
                    if(BOARD.Board[i][j].piece.equals("bp")){
                        if (BOARD.Board[i][j].color == 'b')
                        buttons[i][j].setImageResource(R.drawable.bpb);
                        else
                            buttons[i][j].setImageResource(R.drawable.bpw);
                    }
                    if(BOARD.Board[i][j].piece.equals("wp")){
                        if (BOARD.Board[i][j].color == 'b')
                            buttons[i][j].setImageResource(R.drawable.wpb);
                        else
                            buttons[i][j].setImageResource(R.drawable.wpw);
                    }
                    if(BOARD.Board[i][j].piece.equals("wR")){
                        if (BOARD.Board[i][j].color == 'b')
                            buttons[i][j].setImageResource(R.drawable.wrb);
                        else
                            buttons[i][j].setImageResource(R.drawable.wrw);
                    }
                    if(BOARD.Board[i][j].piece.equals("bR")){
                        if (BOARD.Board[i][j].color == 'b')
                            buttons[i][j].setImageResource(R.drawable.brb);
                        else
                            buttons[i][j].setImageResource(R.drawable.brw);
                    }
                    if(BOARD.Board[i][j].piece.equals("wN")){
                        if (BOARD.Board[i][j].color == 'b')
                            buttons[i][j].setImageResource(R.drawable.wnb);
                        else
                            buttons[i][j].setImageResource(R.drawable.wnw);
                    }
                    if(BOARD.Board[i][j].piece.equals("bN")){
                        if (BOARD.Board[i][j].color == 'b')
                            buttons[i][j].setImageResource(R.drawable.bnb);
                        else
                            buttons[i][j].setImageResource(R.drawable.bnw);
                    }
                    if(BOARD.Board[i][j].piece.equals("wB")){
                        if (BOARD.Board[i][j].color == 'b')
                            buttons[i][j].setImageResource(R.drawable.wbb);
                        else
                            buttons[i][j].setImageResource(R.drawable.wbw);
                    }
                    if(BOARD.Board[i][j].piece.equals("bB")){
                        if (BOARD.Board[i][j].color == 'b')
                            buttons[i][j].setImageResource(R.drawable.bbb);
                        else
                            buttons[i][j].setImageResource(R.drawable.bbw);
                    }
                    if(BOARD.Board[i][j].piece.equals("wQ")){
                        if (BOARD.Board[i][j].color == 'b')
                            buttons[i][j].setImageResource(R.drawable.wqb);
                        else
                            buttons[i][j].setImageResource(R.drawable.wqw);
                    }
                    if(BOARD.Board[i][j].piece.equals("bQ")){
                        if (BOARD.Board[i][j].color == 'b')
                            buttons[i][j].setImageResource(R.drawable.bqb);
                        else
                            buttons[i][j].setImageResource(R.drawable.bqw);
                    }
                    if(BOARD.Board[i][j].piece.equals("wK")){
                        if (BOARD.Board[i][j].color == 'b')
                            buttons[i][j].setImageResource(R.drawable.wkb);
                        else
                            buttons[i][j].setImageResource(R.drawable.wkw);
                    }
                    if(BOARD.Board[i][j].piece.equals("bK")){
                        if (BOARD.Board[i][j].color == 'b')
                            buttons[i][j].setImageResource(R.drawable.bkb);
                        else
                            buttons[i][j].setImageResource(R.drawable.bkw);
                    }

                }
            }
        }


        if (BOARD.CHECKMATE) {
            {
                if (BOARD.TURN.equals("White's "))
                    textDisplay.setText("Checkmate! Black wins");
                else
                    textDisplay.setText("Checkmate! White wins");
            }
            Intent myIntent = new Intent(MainActivity.this, SaveGameActivity.class);
            myIntent.putExtra("key", RECORD); //Optional parameters
            MainActivity.this.startActivity(myIntent);
            }
             else
            if (BOARD.TURN == "Black's " && BOARD.CHECK_ON_BLACK)
                textDisplay.setText("Check: Black's Turn");
            else
            if (BOARD.TURN == "White's " && BOARD.CHECK_ON_WHITE)
            textDisplay.setText("Check: White's Turn");
            else
                textDisplay.setText(BOARD.TURN + " move");
    }


}
