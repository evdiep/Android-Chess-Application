package com.example.testapp;

import android.widget.Button;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import java.io.Serializable;

public class Spot extends AppCompatActivity implements Serializable {
    //color of spot on board just for printing purposes
    char color; // 'w' for white space 'b' for black space
    boolean isEmpty = true;

    Coordinates position = new Coordinates();	//

    String piece; //NULL if empty space
    ImageButton button;
    public Spot() {
        piece = null;
    }

    public Spot(String piece) { // string formt wQ or bK etc.
        this.piece = piece;
        this.isEmpty = false;
    }
    public String toString() { //returns wQ, bK etc, or ##/__ if empty
        if (piece != null)
            return (this.piece + " ");

        else {
            if (this.color == 'b')
                return "## ";
            else
                return "   ";
        }
    }
}
