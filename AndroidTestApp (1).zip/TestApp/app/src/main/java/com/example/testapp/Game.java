package com.example.testapp;
import androidx.annotation.NonNull;

import java.util.ArrayList;

import java.io.Serializable;

public class Game implements Serializable {
    ArrayList<ChessBoard> RECORD;
    String name;
    String date;
    String time;
    public Game(ArrayList<ChessBoard> input, String name, String date, String time){
        this.RECORD = input;
        this.name = name;
        this.date = date;
        this.time = time;
    }

    @NonNull
    @Override
    public String toString() {
        return name;
    }
    public String getName(){
        return this.name;
    }
    public String getDate(){
        return this.date;
    }
    public String getTime(){
        return this.time;
    }

}
