package com.example.testapp;

import android.widget.ArrayAdapter;
import android.content.Context;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class GameAdapter extends ArrayAdapter<Game> {
    private Context mContext;
    private List<Game> GamesList = new ArrayList<>();
    public GameAdapter(Context context, ArrayList<Game> list) {
        super(context, 0 , list);
        mContext = context;
        GamesList = list;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        View listItem = convertView;
        if(listItem == null)
            listItem = LayoutInflater.from(mContext).inflate(R.layout.list_item,parent,false);

        Game currentGame = GamesList.get(position);


        TextView name = (TextView) listItem.findViewById(R.id.gameview_name);
        name.setText(currentGame.getName());

        TextView date = (TextView) listItem.findViewById(R.id.gaveview_date);
        date.setText(currentGame.getDate());

        TextView time = (TextView) listItem.findViewById(R.id.gameview_time);
        time.setText(currentGame.getTime());
        return listItem;
    }
}
