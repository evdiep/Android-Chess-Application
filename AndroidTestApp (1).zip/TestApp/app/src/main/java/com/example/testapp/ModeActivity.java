package com.example.testapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class ModeActivity extends AppCompatActivity {
    Button newgame;
    Button viewgame;
    Button randomplay;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mode);

        newgame = (Button) findViewById(R.id.button_newgame);
        newgame.setOnClickListener(new View.OnClickListener(){
        @Override
        public void onClick(View view) {
            //transfer to loading screen
            Intent myIntent = new Intent(ModeActivity.this, MainActivity.class);
            // myIntent.putExtra("key", RECORD); //Optional parameters
            ModeActivity.this.startActivity(myIntent);
        }
    });

                viewgame = (Button) findViewById(R.id.button_view);
                viewgame.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        //transfer to loading screen
                        Intent myIntent = new Intent(ModeActivity.this, ListActivity.class);
                        // myIntent.putExtra("key", RECORD); //Optional parameters
                        ModeActivity.this.startActivity(myIntent);
                    }
                });

    }
}
