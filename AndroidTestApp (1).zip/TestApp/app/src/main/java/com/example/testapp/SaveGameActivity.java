package com.example.testapp;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import java.util.ArrayList;
import android.widget.EditText;
import android.widget.Toast;

public class SaveGameActivity extends AppCompatActivity {
String name;
EditText nameInput;
EditText dateInput;
EditText timeInput;
Button save_button;
Button dontsave_button;
ArrayList<Game> games;
ArrayList<ChessBoard> RECORD;


//supposed to take input from user to save game under specific name
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_save_game);

        Intent intent = getIntent();
        ArrayList<ChessBoard> RECORD = (ArrayList<ChessBoard>) intent.getSerializableExtra("key");
        System.out.println("done");
        //extracting games list
        games = new ArrayList<Game>();




        nameInput = (EditText) findViewById(R.id.input_name);
        dateInput = (EditText) findViewById(R.id.input_date);
        timeInput = (EditText) findViewById(R.id.input_time);

        save_button = (Button) findViewById(R.id.button_save);
        save_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = nameInput.getText().toString();
                String date = dateInput.getText().toString();
                String time = timeInput.getText().toString();
                Game newgame = new Game(RECORD, name, date, time);
                games.add(newgame);

                Intent myIntent = new Intent(SaveGameActivity.this, ListActivity.class);
                myIntent.putExtra("record",RECORD);
                myIntent.putExtra("name", name);
                myIntent.putExtra("date", date);
                myIntent.putExtra("time", time);//Optional parameters
                SaveGameActivity.this.startActivity(myIntent);
            }
        });
        dontsave_button = (Button) findViewById(R.id.button_dontsave);
        dontsave_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //transfer to loading screen
                Intent myIntent = new Intent(SaveGameActivity.this, ModeActivity.class);
               // myIntent.putExtra("key", RECORD); //Optional parameters
                SaveGameActivity.this.startActivity(myIntent);
            }
        });


    }
}
