package com.example.testapp;


import java.io.*;
import java.util.*;
import android.view.View;
import java.util.ArrayList;
import androidx.appcompat.app.AppCompatActivity;

public class ChessBoard extends AppCompatActivity implements Serializable{
    Spot[][] Board = new Spot[8][8];
    boolean CHECKMATE = false;          /**global variables that determine continuation of game*/
    boolean STALEMATE = false;
    boolean CHECK_ON_WHITE = false;
    boolean CHECK_ON_BLACK = false;
    int lastPawnColumn = -1;//value that stores if the last move was the pawn's double move - used for en passante
    String TURN = "White's "; // change to "Blacks's " after valid move
    /**TURN string used to keep track of which turn, also printed out each iteration*/
    public ChessBoard() {   //initializes board and pieces
        /** @author Evan Diep/ed430 *
         * initilizes 8x8 array of spot objects and stores all game piece in correct order*/
        for(int i = 0; i < 8; i++) {

            for(int j = 0; j < 8; j++) {

                if (((i+1) % 2) != 0 && ((j+1) % 2) != 0) {//ODD ROW ODD COLUMN
                    Board[i][j] = new Spot();
                    Board[i][j].color = 'w';
                    Board[i][j].position = new Coordinates (j, i);
                }
                else if (((i+1) % 2) == 0 && ((j+1) % 2) == 0) {//EVEN ROW EVEN COLUMN
                    Board[i][j] = new Spot();
                    Board[i][j].color = 'w';
                    Board[i][j].position = new Coordinates (j, i);
                }
                else {
                    Board[i][j] = new Spot();
                    Board[i][j].color = 'b';
                    Board[i][j].position = new Coordinates (j, i);
                }
                if (i == 1) {
                    Board[i][j].piece = "bp";
                    Board[i][j].isEmpty = false;
                }
                else if (i == 6) {
                    Board[i][j].piece = "wp";
                    Board[i][j].isEmpty = false;
                }
                else
                    Board[i][j].piece = null;
            }
        }
        Board[0][0].piece = "bR"; Board[0][1].piece = "bN";
        Board[0][2].piece = "bB"; Board[0][3].piece = "bQ";
        Board[0][4].piece = "bK"; Board[0][5].piece = "bB";
        Board[0][6].piece = "bN"; Board[0][7].piece = "bR";

        Board[7][0].piece = "wR"; Board[7][1].piece = "wN";
        Board[7][2].piece = "wB"; Board[7][3].piece = "wQ";
        Board[7][4].piece = "wK"; Board[7][5].piece = "wB";
        Board[7][6].piece = "wN"; Board[7][7].piece = "wR";


        for (int i = 0; i <= 7; i++) {
            Board[0][i].isEmpty = false;
            Board[7][i].isEmpty = false;
        }
    }
    public void printBoard() { /**prints Board in expected assignment format */

        for(int i = 0; i < 8; i++) {
            for(int j =0; j < 8; j++) {
                System.out.print(Board[i][j].toString());
            }
            System.out.println(" " +(8-i) + ""); //prints grid numbers
        }
        System.out.println(" a  b  c  d  e  f  g  h"); //prints grid numbers
        System.out.println(""); //extra line for formatting
    }
    public ChessBoard copy(ChessBoard input) {  /**method that copies a chessboard
     useful later on for using to predict check moves*/
        ChessBoard temp = new ChessBoard();
        for (int i =0; i<8; i++) {
            for (int j =0; j<8; j++) {
                if (input.Board[i][j].piece != null)
                    temp.Board[i][j].piece = input.Board[i][j].piece;
                else
                    temp.Board[i][j].piece = null;
                temp.Board[i][j].isEmpty = input.Board[i][j].isEmpty;
            }
            temp.CHECK_ON_BLACK = input.CHECK_ON_BLACK;
            temp.CHECK_ON_WHITE = input.CHECK_ON_WHITE;
            temp.TURN = input.TURN;

        }
        return temp;
    }

    public void Move(Coordinates oldposition, Coordinates newposition) { /**
     @param
     takes a Coordinates object of initial piece and moves it to coordinates of newposition and
     then switches "White's " to "Black's " to signify turn switch*/
        //moves piece in spot to another and switches TURN

        Board[newposition.y][newposition.x].piece = Board[oldposition.y][oldposition.x].piece;
        Board[oldposition.y][oldposition.x].piece = null;
        Board[newposition.y][newposition.x].isEmpty = false;
        Board[oldposition.y][oldposition.x].isEmpty = true;
        /**@author Brian Brown  implements castling moves for rook and kings, checks if pieces are in
         * correct position and moves rook after king is moved*/
        if (oldposition.x == 4 && oldposition.y == 7) {
            if (newposition.x == 6 && newposition.y == 7 && Board[7][7].piece == "wR") {
                Board[7][7].piece = null;
                Board[7][7].isEmpty = true;
                Board[7][5].piece = "wR";
                Board[7][5].isEmpty = false;
            }
            if (newposition.x == 2 && newposition.y == 7 && Board[7][0].piece == "wR") {
                Board[7][0].piece = null;
                Board[7][0].isEmpty = true;
                Board[7][3].piece = "wR";
                Board[7][3].isEmpty = false;
            }
        }

        if (oldposition.x == 4 && oldposition.y == 0) { //and piece at each of those coordinates is correct
            if (newposition.x == 2 && newposition.y == 0 && Board[0][0].piece == "bR") {
                Board[0][0].piece = null;
                Board[0][0].isEmpty = true;
                Board[0][3].piece = "bR";
                Board[0][3].isEmpty = false;
            }
            if (newposition.x == 6 && newposition.y == 0 && Board[0][7].piece == "bR") {
                Board[0][7].piece = null;
                Board[0][7].isEmpty = true;
                Board[0][5].piece = "bR";
                Board[0][5].isEmpty = false;
            }
        } /**switches turn*/

        //seeing if en passant capture occured
        if(Board[newposition.y][newposition.x].piece.equals("bp") && newposition.y == 5) {
            if(newposition.x == lastPawnColumn && Board[4][lastPawnColumn].piece.equals("wp")) {
                Board[4][lastPawnColumn].piece = null;
                Board[4][lastPawnColumn].isEmpty = true;
            }
        }
        if(Board[newposition.y][newposition.x].piece.equals("wp") && newposition.y == 2) {
            if(newposition.x == lastPawnColumn && Board[3][lastPawnColumn].piece.equals("bp")) {
                Board[3][lastPawnColumn].piece = null;
                Board[3][lastPawnColumn].isEmpty = true;
            }
        }

        //storing lastPawnColumn value for
        if(Board[newposition.y][newposition.x].piece.equals("bp") && newposition.y == 3) {
            lastPawnColumn = newposition.x;
        }else if(Board[newposition.y][newposition.x].piece.equals("wp") && newposition.y == 4) {
            lastPawnColumn = newposition.x;
        }else{
            lastPawnColumn = -1;
        }

        if (TURN.equals("White's "))
            TURN = "Black's ";
        else
            TURN = "White's ";

    }

    //returns arraylist of all possible moves of a piece
    public ArrayList<Coordinates> Possible_Moves(Spot input){
        /**@author Evan Diep
         * @param takes a Spot object as input and returns an arraylist of Coordinate objects that
         * contain all possible valid moves that piece can make
         */
        ArrayList<Coordinates> moves = new ArrayList<Coordinates>();
        int x = input.position.x; int y = input.position.y;

	/*	if(input.piece.charAt(0) == 'b' && TURN.equals("White's ")) {
			return moves;
		}
		if(input.piece.charAt(0) == 'w' && TURN.equals("Black's ")) {
			return moves;
		} */
        if (input.piece != null) {
            if (input.piece.equals("wp")) { /**@author Brian Brown
            implements pawn moves and captures by check indices 1-2 spaces away in Board
            pawn can move double first at in row 1 and 6
            if a move is valid, its coordinates are added into the arraylist
            checks if move is valid by see if a team piece is in the way or if enemy piece is capturable*/

                if (y != 0 && Board[y-1][x].isEmpty) {
                    moves.add(new Coordinates(x, y-1));
                    if (y == 6 && Board[y-2][x].isEmpty)//first move for pawn
                        moves.add(new Coordinates(x,y-2));
                }
                if(x!=0 && x!= 7 && y!=0 ) {//diagonal move to capture

                    if (!Board[y-1][x+1].isEmpty && Board[y-1][x+1].piece.charAt(0) == 'b') // Board[y-1][x+1].piece)
                        moves.add(new Coordinates(x+1, y-1));
                    if (!Board[y-1][x-1].isEmpty && Board[y-1][x-1].piece.charAt(0) == 'b')
                        moves.add(new Coordinates(x-1, y-1));
                    if (!Board[y][x+1].isEmpty && Board[y][x+1].piece.equals("bp") && y == 3)
                        moves.add(new Coordinates(x+1, y-1));
                    if (!Board[y][x-1].isEmpty && Board[y][x-1].piece.equals("bp") && y == 3)
                        moves.add(new Coordinates(x-1, y-1));
                }
                if(x == 0 && y!=0) {
                    if (!Board[y-1][x+1].isEmpty && Board[y-1][x+1].piece.charAt(0) == 'b')
                        moves.add(new Coordinates(x+1, y-1));
                    if (!Board[y][x+1].isEmpty && Board[y][x+1].piece.equals("bp") && y == 3)
                        moves.add(new Coordinates(x+1, y-1));
                }
                if(x == 7 && y!=0) {
                    if (!Board[y-1][x-1].isEmpty && Board[y-1][x-1].piece.charAt(0) == 'b')
                        moves.add(new Coordinates(x-1, y-1));
                    if (!Board[y][x-1].isEmpty && Board[y][x-1].piece.equals("bp") && y == 3)
                        moves.add(new Coordinates(x-1, y-1));
                }

                return moves;
            }
            if (input.piece.equals("bp")) {

                if (y!= 7 && Board[y+1][x].isEmpty) {
                    moves.add(new Coordinates(x, y+1));
                    if (y == 1 && Board[y+2][x].isEmpty)//first move for pawn
                        moves.add(new Coordinates(x,y+2));
                }
                if(x!=0 && y!= 7 && x!=7) {//diagonal move for capture
                    if (!Board[y+1][x+1].isEmpty && Board[y+1][x+1].piece.charAt(0) == 'w')
                        moves.add(new Coordinates(x+1, y+1));
                    if (!Board[y+1][x-1].isEmpty && Board[y+1][x-1].piece.charAt(0) == 'w')
                        moves.add(new Coordinates(x-1, y+1));
                    if(!Board[y][x+1].isEmpty && Board[y][x+1].piece.equals("wp") && y == 4)
                        moves.add(new Coordinates(x+1, y+1));
                    if(!Board[y][x-1].isEmpty && Board[y][x-1].piece.equals("wp") && y == 4)
                        moves.add(new Coordinates(x-1, y+1));
                }
                if(x == 0 && y!=7) {
                    if (!Board[y+1][x+1].isEmpty && Board[y+1][x+1].piece.charAt(0) == 'w')
                        moves.add(new Coordinates(x+1, y+1));
                    if(!Board[y][x+1].isEmpty && Board[y][x+1].piece.equals("wp") && y == 4)
                        moves.add(new Coordinates(x+1, y+1));
                }
                if(x == 7 && y!=7) {
                    if (!Board[y+1][x-1].isEmpty && Board[y+1][x-1].piece.charAt(0) == 'w')
                        moves.add(new Coordinates(x-1, y+1));
                    if(!Board[y][x-1].isEmpty && Board[y][x-1].piece.equals("wp") && y == 4)
                        moves.add(new Coordinates(x-1, y+1));
                }


                return moves;
            }
            if (input.piece.equals("bN")){ /** @author Evan Diep  implemented knights in similar way to pawns*/

                if((y+1) < 8 && (x+2) < 8){
                    if (Board[y+1][x+2].isEmpty || Board[y+1][x+2].piece.charAt(0) == 'w')
                        moves.add(new Coordinates(x+2,y+1));
                }
                if((y+1) < 8 && (x-2) >= 0){
                    if (Board[y+1][x-2].isEmpty || Board[y+1][x-2].piece.charAt(0) == 'w')
                        moves.add(new Coordinates(x-2,y+1));
                }
                if((y-1) >= 0 && (x+2) < 8){
                    if (Board[y-1][x+2].isEmpty || Board[y-1][x+2].piece.charAt(0) == 'w')
                        moves.add(new Coordinates(x+2,y-1));
                }
                if((y-1) >= 0 && (x-2) >= 0){
                    if (Board[y-1][x-2].isEmpty || Board[y-1][x-2].piece.charAt(0) == 'w')
                        moves.add(new Coordinates(x-2,y-1));
                }

                if((y+2) < 8 && (x+1) < 8){
                    if (Board[y+2][x+1].isEmpty || Board[y+2][x+1].piece.charAt(0) == 'w')
                        moves.add(new Coordinates(x+1,y+2));
                }
                if((y+2) < 8 && (x-1) >= 0){
                    if (Board[y+2][x-1].isEmpty || Board[y+2][x-1].piece.charAt(0) == 'w')
                        moves.add(new Coordinates(x-1,y+2));
                }
                if((y-2) >= 0 && (x+1) < 8){
                    if (Board[y-2][x+1].isEmpty || Board[y-2][x+1].piece.charAt(0) == 'w')
                        moves.add(new Coordinates(x+1,y-2));
                }
                if((y-2) >= 0 && (x-1) >= 0){
                    if (Board[y-2][x-1].isEmpty || Board[y-2][x-1].piece.charAt(0) == 'w')
                        moves.add(new Coordinates(x-1,y-2));
                }
                return moves;
            }

            if (input.piece.equals("wN")){ /**reusing code*/

                if((y+1) < 8 && (x+2) < 8){
                    if (Board[y+1][x+2].isEmpty || Board[y+1][x+2].piece.charAt(0) == 'b')
                        moves.add(new Coordinates(x+2,y+1));
                }
                if((y+1) < 8 && (x-2) >= 0){
                    if (Board[y+1][x-2].isEmpty || Board[y+1][x-2].piece.charAt(0) == 'b')
                        moves.add(new Coordinates(x-2,y+1));
                }
                if((y-1) >= 0 && (x+2) < 8){
                    if (Board[y-1][x+2].isEmpty || Board[y-1][x+2].piece.charAt(0) == 'b')
                        moves.add(new Coordinates(x+2,y-1));
                }
                if((y-1) >= 0 && (x-2) >= 0){
                    if (Board[y-1][x-2].isEmpty || Board[y-1][x-2].piece.charAt(0) == 'b')
                        moves.add(new Coordinates(x-2,y-1));
                }

                if((y+2) < 8 && (x+1) < 8){
                    if (Board[y+2][x+1].isEmpty || Board[y+2][x+1].piece.charAt(0) == 'b')
                        moves.add(new Coordinates(x+1,y+2));
                }
                if((y+2) < 8 && (x-1) >= 0){
                    if (Board[y+2][x-1].isEmpty || Board[y+2][x-1].piece.charAt(0) == 'b')
                        moves.add(new Coordinates(x-1,y+2));
                }
                if((y-2) >= 0 && (x+1) < 8){
                    if (Board[y-2][x+1].isEmpty || Board[y-2][x+1].piece.charAt(0) == 'b')
                        moves.add(new Coordinates(x+1,y-2));
                }
                if((y-2) >= 0 && (x-1) >= 0){
                    if (Board[y-2][x-1].isEmpty || Board[y-2][x-1].piece.charAt(0) == 'b')
                        moves.add(new Coordinates(x-1,y-2));
                }
                return moves;
            }
            if (input.piece.equals("wR")) { /** @author Evan Diep, implements rooks*/
                for (int i = 1; (y+i)< 8; i++) { //rook moving down
                    if (Board[y+i][x].isEmpty) {
                        moves.add(new Coordinates(x, y+i));
                        continue;
                    }
                    if (Board[y+i][x].piece.charAt(0)== 'b') {
                        moves.add(new Coordinates(x, y+i));
                        break;
                    }else
                        break; //piece is a white piece thats in the way

                }
                for (int i = 1; (y-i)>= 0; i++) { //rook moving up
                    if (Board[y-i][x].isEmpty) {
                        moves.add(new Coordinates(x, y-i));
                        continue;
                    }
                    if (Board[y-i][x].piece.charAt(0)== 'b') {
                        moves.add(new Coordinates(x, y-i));
                        break;
                    }else
                        break; //piece is a white piece thats in the way

                }
                for (int i = 1; (x+i)< 8; i++) { //rook moves to right
                    if (Board[y][x+i].isEmpty) {
                        moves.add(new Coordinates(x+i, y));
                        continue;
                    }
                    if (Board[y][x+i].piece.charAt(0)== 'b') {
                        moves.add(new Coordinates(x+i, y));
                        break;
                    }else
                        break; //piece is a white piece thats in the way

                }
                for (int i = 1; (x-i)>= 0; i++) { //rook moves to left
                    if (Board[y][x-1].isEmpty) {
                        moves.add(new Coordinates(x-i, y));
                        continue;
                    }
                    if (Board[y][x-1].piece.charAt(0)== 'b') {
                        moves.add(new Coordinates(x-i, y));
                        break;
                    }else
                        break; //piece is a white piece thats in the way

                }

                return moves;
            }
            if (input.piece.equals("bR")) {
                for (int i = 1; (y+i)< 8; i++) { //rook moving down
                    if (Board[y+i][x].isEmpty) {
                        moves.add(new Coordinates(x, y+i));
                        continue;
                    }
                    if (Board[y+i][x].piece.charAt(0)== 'w') {
                        moves.add(new Coordinates(x, y+i));
                        break;
                    }else
                        break; //piece is a white piece thats in the way

                }
                for (int i = 1; (y-i)>= 0; i++) { //rook moving up
                    if (Board[y-i][x].isEmpty) {
                        moves.add(new Coordinates(x, y-i));
                        continue;
                    }
                    if (Board[y-i][x].piece.charAt(0)== 'w') {
                        moves.add(new Coordinates(x, y-i));
                        break;
                    }else
                        break; //piece is a white piece thats in the way

                }
                for (int i = 1; (x+i)< 8; i++) { //rook moves to right
                    if (Board[y][x+i].isEmpty) {
                        moves.add(new Coordinates(x+i, y));
                        continue;
                    }
                    if (Board[y][x+i].piece.charAt(0)== 'w') {
                        moves.add(new Coordinates(x+i, y));
                        break;
                    }else
                        break; //piece is a white piece thats in the way

                }
                for (int i = 1; (x-i)>= 0; i++) { //rook moves to left
                    if (Board[y][x-1].isEmpty) {
                        moves.add(new Coordinates(x-i, y));
                        continue;
                    }
                    if (Board[y][x-1].piece.charAt(0)== 'w') {
                        moves.add(new Coordinates(x-i, y));
                        break;
                    }else
                        break; //piece is a white piece thats in the way

                }

                return moves;
            }
            if (input.piece.equals("bB")){ /** @author Evan Diep implements bishops**/
                for (int i = 1; ((x-i)>= 0 && (y-i)>=0); i++) { //black rook moves upper left
                    if (Board[y-i][x-i].isEmpty) {
                        moves.add(new Coordinates(x-i, y-i));
                        continue;
                    }
                    if (Board[y-i][x-i].piece.charAt(0)== 'w') { //white piece in the way
                        moves.add(new Coordinates(x-i, y-i));
                        break;
                    }else
                        break; //piece is a white piece thats in the way

                }
                for (int i = 1; (x+i) < 8 && (y-i) >= 0; i++) { //black rook moves upper right
                    if (Board[y-i][x+i].isEmpty) {
                        moves.add(new Coordinates(x+i, y-i));
                        continue;
                    }
                    if (Board[y-i][x+i].piece.charAt(0)== 'w') { //white piece in the way
                        moves.add(new Coordinates(x+i, y-i));
                        break;
                    }else
                        break; //piece is a white piece thats in the way

                }
                for (int i = 1; (x+i) < 8 && (y+i) < 8; i++) { //black rook moves lower right
                    if (Board[y+i][x+i].isEmpty) {
                        moves.add(new Coordinates(x+i, y+i));
                        continue;
                    }
                    if (Board[y+i][x+i].piece.charAt(0)== 'w') { //white piece in the way
                        moves.add(new Coordinates(x+i, y+i));
                        break;
                    }else
                        break; //piece is a white piece thats in the way

                }
                for (int i = 1; (x-i) >= 0 && (y+i) < 8; i++) { //black rook moves lower left
                    if (Board[y+i][x-i].isEmpty) {
                        moves.add(new Coordinates(x-i, y+i));
                        continue;
                    }
                    if (Board[y+i][x-i].piece.charAt(0)== 'w') { //white piece in the way
                        moves.add(new Coordinates(x-i, y+i));
                        break;
                    }else
                        break; //piece is a white piece thats in the way

                }
                return moves;
            }
            if (input.piece.equals("wB")){
                for (int i = 1; ((x-i)>= 0 && (y-i)>=0); i++) { //white rook moves upper left
                    if (Board[y-i][x-i].isEmpty) {
                        moves.add(new Coordinates(x-i, y-i));
                        continue;
                    }
                    if (Board[y-i][x-i].piece.charAt(0)== 'b') { //white piece in the way
                        moves.add(new Coordinates(x-i, y-i));
                        break;
                    }else
                        break; //piece is a white piece thats in the way

                }
                for (int i = 1; (x+i) < 8 && (y-i) >= 0; i++) { //white rook moves upper right
                    if (Board[y-i][x+i].isEmpty) {
                        moves.add(new Coordinates(x+i, y-i));
                        continue;
                    }
                    if (Board[y-i][x+i].piece.charAt(0)== 'b') { //black piece in the way
                        moves.add(new Coordinates(x+i, y-i));
                        break;
                    }else
                        break; //piece is a white piece thats in the way

                }
                for (int i = 1; (x+i) < 8 && (y+i) < 8; i++) { //white rook moves lower right
                    if (Board[y+i][x+i].isEmpty) {
                        moves.add(new Coordinates(x+i, y+i));
                        continue;
                    }
                    if (Board[y+i][x+i].piece.charAt(0)== 'b') { //black piece in the way
                        moves.add(new Coordinates(x+i, y+i));
                        break;
                    }else
                        break; //piece is a white piece thats in the way

                }
                for (int i = 1; (x-i) >= 0 && (y+i) < 8; i++) { //white rook moves lower left
                    if (Board[y+i][x-i].isEmpty) {
                        moves.add(new Coordinates(x-i, y+i));
                        continue;
                    }
                    if (Board[y+i][x-i].piece.charAt(0)== 'b') { //black piece in the way
                        moves.add(new Coordinates(x-i, y+i));
                        break;
                    }else
                        break; //piece is a white piece thats in the way

                }
                return moves;
            }     /** changes string to bishop then calls method recursively to gain all bishop moves
             then does the same for a rook because bishop + rook = queen*/
            if (input.piece.equals("wQ")) {
                input.piece = "wB";			//if it were a bishop AND a rook
                moves.addAll(Possible_Moves(input));
                input.piece = "wR";
                moves.addAll(Possible_Moves(input));
                input.piece = "wQ";
                return moves;
            }
            if (input.piece.equals("bQ")) { //recursively uses function to add all moves
                input.piece = "bB";			//if it were a bishop AND a rook
                moves.addAll(Possible_Moves(input));
                input.piece = "bR";
                moves.addAll(Possible_Moves(input));
                input.piece = "bQ";
                return moves;
            }

            if (input.piece.equals("wK")) {  /**@author Brian Brown implements king moves*/
                if (  (x-1) >= 0 && (y-1)>=0 &&  //top left
                        (Board[y-1][x-1].isEmpty || Board[y-1][x-1].piece.charAt(0) == 'b'))
                    moves.add(new Coordinates(x-1, y-1));
                if (  (y-1)>=0 &&    //top
                        (Board[y-1][x].isEmpty || Board[y-1][x].piece.charAt(0) == 'b'))
                    moves.add(new Coordinates(x, y-1));
                if (  (x+1)< 8 && (y-1)>=0 &&  //top right
                        (Board[y-1][x+1].isEmpty || Board[y-1][x+1].piece.charAt(0) == 'b'))
                    moves.add(new Coordinates(x+1, y-1));

                if (  (x-1) >= 0 && (y+1)< 8 &&  //bot left
                        (Board[y+1][x-1].isEmpty || Board[y+1][x-1].piece.charAt(0) == 'b'))
                    moves.add(new Coordinates(x-1, y+1));
                if (  (y+1) <8 &&  				//bot
                        (Board[y+1][x].isEmpty || Board[y+1][x].piece.charAt(0) == 'b'))
                    moves.add(new Coordinates(x, y+1));
                if (  (x+1)< 8 && (y+1) < 8 && 	//bot right
                        (Board[y+1][x+1].isEmpty || Board[y+1][x+1].piece.charAt(0) == 'b'))
                    moves.add(new Coordinates(x+1, y+1));
                if (  (x+1)< 8 && 	//right
                        (Board[y][x+1].isEmpty || Board[y][x+1].piece.charAt(0) == 'b'))
                    moves.add(new Coordinates(x+1, y));
                if (  (x-1)>= 0 && 	//left
                        (Board[y][x-1].isEmpty || Board[y][x-1].piece.charAt(0) == 'b'))
                    moves.add(new Coordinates(x-1, y));
            }

            if (input.piece.equals("bK")) {
                if (  (x-1) >= 0 && (y-1)>=0 &&  //top left
                        (Board[y-1][x-1].isEmpty || Board[y-1][x-1].piece.charAt(0) == 'w'))
                    moves.add(new Coordinates(x-1, y-1));
                if (  (y-1)>=0 &&    //top
                        (Board[y-1][x].isEmpty || Board[y-1][x].piece.charAt(0) == 'w'))
                    moves.add(new Coordinates(x, y-1));
                if (  (x+1)< 8 && (y-1)>=0 &&  //top right
                        (Board[y-1][x+1].isEmpty || Board[y-1][x+1].piece.charAt(0) == 'w'))
                    moves.add(new Coordinates(x+1, y-1));

                if (  (x-1) >= 0 && (y+1)< 8 &&  //bot left
                        (Board[y+1][x-1].isEmpty || Board[y+1][x-1].piece.charAt(0) == 'w'))
                    moves.add(new Coordinates(x-1, y+1));
                if (  (y+1) <8 &&  				//bot
                        (Board[y+1][x].isEmpty || Board[y+1][x].piece.charAt(0) == 'w'))
                    moves.add(new Coordinates(x, y+1));
                if (  (x+1)< 8 && (y+1)<8 && 	//bot right
                        (Board[y+1][x+1].isEmpty || Board[y+1][x+1].piece.charAt(0) == 'w'))
                    moves.add(new Coordinates(x+1, y+1));
                if (  (x+1)< 8 && 	//right
                        (Board[y][x+1].isEmpty || Board[y][x+1].piece.charAt(0) == 'w'))
                    moves.add(new Coordinates(x+1, y));
                if (  (x-1)>= 0 && 	//left
                        (Board[y][x-1].isEmpty || Board[y][x-1].piece.charAt(0) == 'w'))
                    moves.add(new Coordinates(x-1, y));
            }
		/*fix possible king movements later
		if (input.piece.equals("wK") || input.piece.equals("bK")) {
			if(x > 0 && x < 7 && y > 0 && y < 7) {
				if (Board[y+1][x].isEmpty || Board[y+1][x].piece.charAt(0)== 'b')
				moves.add(new Coordinates(x, y+1));
				if (Board[y-1][x].isEmpty || Board[y-1][x].piece.charAt(0)== 'b')
				moves.add(new Coordinates(x, y-1));
				if (Board[y][x+1].isEmpty || Board[y][x+1].piece.charAt(0)== 'b')
				moves.add(new Coordinates(x+1, y));
				if (Board[y][x-1].isEmpty || Board[y][x-1].piece.charAt(0)== 'b')
				moves.add(new Coordinates(x-1, y));
			}
			else if(x > 0 && x < 7) {
				if(y == 0) {
					moves.add(new Coordinates(x, y+1));
					moves.add(new Coordinates(x+1, y));
					moves.add(new Coordinates(x-1, y));
				}
				if(y == 7) {
					moves.add(new Coordinates(x, y-1));
					moves.add(new Coordinates(x+1, y));
					moves.add(new Coordinates(x-1, y));
				}
			}
			else if(y > 0 && y < 7) {
				if(x == 0) {
					moves.add(new Coordinates(x, y+1));
					moves.add(new Coordinates(x, y-1));
					moves.add(new Coordinates(x+1, y));
				}
				if(x == 7) {
					moves.add(new Coordinates(x, y+1));
					moves.add(new Coordinates(x, y-1));
					moves.add(new Coordinates(x-1, y));
				}

			}else {
				if(x == 0 && y == 0) {
					moves.add(new Coordinates(x, y+1));
					moves.add(new Coordinates(x+1, y));
				}
				if(x == 0 && y == 7) {
					moves.add(new Coordinates(x, y-1));
					moves.add(new Coordinates(x+1, y));
				}
				if(x == 7 && y == 0) {
					moves.add(new Coordinates(x, y+1));
					moves.add(new Coordinates(x-1, y));
				}
				if(x == 7 && y == 7) {
					moves.add(new Coordinates(x, y-1));
					moves.add(new Coordinates(x-1, y));
				}
			}	*/

            //checking if it can castle
            /**@author Brian Brown checks if king is in castling positions*/
            if(input.piece.equals("wK")) {
                if(x == 4 && y == 7) {
                    if(Board[y][x+1].isEmpty && Board[y][x+2].isEmpty && Board[y][x+3].piece=="wR") {
                        moves.add(new Coordinates(x+2, y));
                    }
                    if(Board[y][x-1].isEmpty && Board[y][x-2].isEmpty && Board[y][x-3].isEmpty && Board[y][x-4].piece=="wR") {
                        moves.add(new Coordinates(x-2, y));
                    }
                }
            }else { // bk
                if(x == 4 && y == 0) {
                    if(Board[y][x-1].isEmpty && Board[y][x-2].isEmpty && Board[y][x-3].isEmpty && Board[y][x-4].piece=="bR") {
                        moves.add(new Coordinates(x-2, y));
                    }
                    if(Board[y][x+1].isEmpty && Board[y][x+2].isEmpty && Board[y][x+3].piece=="bR") {
                        moves.add(new Coordinates(x+2, y));
                    }
                }
            }

            if(input.piece.equals("wK")) {
                ArrayList<Coordinates> black_moves = new ArrayList<Coordinates>();
                for(int i = 0; i < 8; i++) {
                    for (int j = 0; j < 8; j++) {
                        if(!Board[i][j].isEmpty && Board[i][j].piece.charAt(0) == 'b') {
                            black_moves.addAll(Possible_Moves(Board[i][j]));
                        }
                    }
                }

            }


            return moves;
        }
        return moves;
    }

    //searches arraylist of all possible moves to check if move being asked is in there
    /** @author Evan Diep
     *
     * @param curr coordinates of piece being moved
     * @param target coordinates of destination
     * @return returns positive integer if destination is a valid move found in arraylist
     * 	        returns -1 if not found in arraylist or if move leads to own king being checked
     *  		or if king is currently in check, returns -1 if the move doesnt remove king from check
     */
    public int Search_Moves(Coordinates curr, Coordinates target) {
        ArrayList<Coordinates> moves = Possible_Moves(Board[curr.y][curr.x]);
        int i = 0; int ret = -1;

        while(i < moves.size()) {
            if (moves.get(i).equals(target)) {
                ret = i;
                i = 10000;
            }
            i++;
        }
        if (ret != -1) { //makes sure you cant put your own king in check
            ChessBoard temp = new ChessBoard();
            temp = temp.copy(this);
            temp.Move(curr, target);
            temp.Analyze();
            if (this.TURN.equals("White's ") && temp.CHECK_ON_WHITE){
                ret = -1;
            }
            if (this.TURN.equals("Black's ") && temp.CHECK_ON_BLACK){
                ret = -1;
            }
        }

        if (CHECK_ON_BLACK) { //when checked, king has to move king out of check
            if (ret != -1) {
                ChessBoard temp = copy(this);
                temp.Move(curr, target);
                temp.Analyze();
                if (temp.CHECK_ON_BLACK)
                    ret = -1;
            }
        }

        if (CHECK_ON_WHITE) { //when check, king has to move king out of check
            if (ret != -1) {
                ChessBoard temp = copy(this);
                temp.Move(curr, target);
                temp.Analyze();
                if (temp.CHECK_ON_WHITE)
                    ret = -1;
            }
        }
		/*if (ret != -1) {
			Spot temp = new Spot();
			if (temp.piece!= null)
				temp.piece = Board[target.y][target.x].piece;
			this.Move(curr, target);
		 //checks if players move will put their own king in check
				if (CHECK_ON_WHITE && TURN.equals("White's ")) {
					ret = -1;
					CHECK_ON_WHITE = false;
				}
				if (CHECK_ON_BLACK && TURN.equals("Black's ")) {
					ret = -1;
					CHECK_ON_BLACK = false;
				}
				//switches back spots
					Board[curr.y][curr.x].piece = Board[target.y][target.x].piece;
					Board[curr.y][curr.x].isEmpty = false;
					if (temp.piece != null) {
					Board[target.y][target.x].piece = temp.piece;
					Board[target.y][target.x].isEmpty = false;
					}
					else {
						Board[target.y][target.x].piece = null;
						Board[target.y][target.x].isEmpty = true;
					}

			} */

        return ret;

    }
    public void Stalemated() { /**@author Evan Diep
    analyzes if stalemate conditions are fulfulled.
    Stalemate if king is not in check but has no valid moves either  */
        if (TURN.equals("Black's ")) {
            for(int i = 0; i < 8; i++) {
                for(int j =0; j < 8; j++) {
                    ArrayList<Coordinates> moves = new ArrayList<Coordinates>();
                    if(!this.Board[i][j].isEmpty && this.Board[i][j].piece.charAt(0)=='b') {
                        moves = Possible_Moves(this.Board[i][j]);
                        int k = 0;
                        while (k < moves.size()) {
                            ChessBoard temp = copy(this);
                            temp.Move(new Coordinates(j,i), moves.get(k));
                            temp.Analyze();
                            if (!temp.CHECK_ON_BLACK){
                                CHECKMATE = false;
                                return;
                            }
                            k++;
                        }

                    }
                }
            }
            if (!CHECK_ON_BLACK)
                STALEMATE = true;
            return;
        }
        if (TURN.equals("White's ")) {
            for(int i = 0; i < 8; i++) {
                for(int j =0; j < 8; j++) {
                    ArrayList<Coordinates> moves = new ArrayList<Coordinates>();
                    if(!this.Board[i][j].isEmpty && this.Board[i][j].piece.charAt(0)=='w') {
                        moves = Possible_Moves(this.Board[i][j]);
                        int k = 0;
                        while (k < moves.size()) {
                            ChessBoard temp = copy(this);
                            temp.Move(new Coordinates(j,i), moves.get(k));
                            temp.Analyze();
                            if (!temp.CHECK_ON_WHITE){
                                CHECKMATE = false;
                                return;
                            }
                            k++;
                        }

                    }
                }
            }
            if (!CHECK_ON_WHITE)
                STALEMATE = true;
            return;
        }
    }
    public void Checkmated() { /** @author Evan Diep checks if there are any possible moves to make without being checked
    sets boolean CHECKMATE to true if not

    determines checkmate by checking through every possible move of an ally piece on the board to see if
    it leads to king not being in check, by creating a duplicate board and running the analyze method on it */

        if (TURN.equals("Black's ")) {
            for(int i = 0; i < 8; i++) {
                for(int j =0; j < 8; j++) {
                    ArrayList<Coordinates> moves = new ArrayList<Coordinates>();
                    if(!this.Board[i][j].isEmpty && this.Board[i][j].piece.charAt(0)=='b') {
                        moves = Possible_Moves(this.Board[i][j]);
                        int k = 0;
                        while (k < moves.size()) {
                            ChessBoard temp = copy(this);
                            temp.Move(new Coordinates(j,i), moves.get(k));
                            temp.Analyze();
                            if (!temp.CHECK_ON_BLACK){
                                CHECKMATE = false;
                                return;
                            }
                            k++;
                        }

                    }
                }
            }
            CHECKMATE = true;
            return;
        }
        else  {
            for(int i = 0; i < 8; i++) {
                for(int j =0; j < 8; j++) {
                    ArrayList<Coordinates> moves = new ArrayList<Coordinates>();
                    if(!this.Board[i][j].isEmpty && this.Board[i][j].piece.charAt(0)=='w') {
                        moves = Possible_Moves(this.Board[i][j]);
                        int k = 0;
                        while (k < moves.size()) {
                            ChessBoard temp = copy(this);
                            temp.Move(new Coordinates(j,i), moves.get(k));
                            temp.Analyze();
                            if (!temp.CHECK_ON_WHITE){
                                CHECKMATE = false;
                                return;
                            }
                            k++;
                        }

                    }
                }
            }
            CHECKMATE = true;
            return;
        }
    }
    /*
    }
        if (CHECK_ON_WHITE) {
            for(int i =0; i<8; i++) {
                for(int j=0; j<8; j++) {
                    ArrayList<Coordinates> moves = new ArrayList<Coordinates>();
                    moves = Possible_Moves(this.Board[i][j]);
                    int k = 0;
                    ChessBoard temp = copy(this);
                    CHECKMATE = true;
                    while (k < moves.size()) {
                        temp.Move(new Coordinates(j,i), moves.get(k));
                        temp.Analyze();
                        if (!temp.CHECK_ON_WHITE) {
                            CHECKMATE = false;
                            break;
                        }
                        k++;
                    }
                }
                if(!CHECKMATE)
                    return;
            }
        }

        if (CHECK_ON_BLACK) {
            for(int i =0; i<8; i++) {
                for(int j=0; j<8; j++) {
                    ArrayList<Coordinates> moves = new ArrayList<Coordinates>();
                    moves = Possible_Moves(this.Board[i][j]);
                    int k = 0;
                    ChessBoard temp = copy(this);
                    CHECKMATE = true;
                    while (k < moves.size()) {
                        temp.Move(new Coordinates(j,i), moves.get(k));
                        temp.Analyze();
                        if (!temp.CHECK_ON_BLACK) {
                            CHECKMATE = false;
                            break;
                        }
                        k++;
                    }
                    if(!CHECKMATE)
                        return;
                }
            }

        }
    }
        */
    public void Analyze() { /**@author Evan Diep
    bx, by are values for indices of black king. wx wy same for white king
    black_moves and white_moves are respective arraylists that contain coordinate objects
    for all possible moves of their pieces
     */
        //checks if either king is in check/ or checkmated
        int bx = -1; int by = -1; int wx =-1; int wy=-1;
        ArrayList<Coordinates> black_moves = new ArrayList<Coordinates>();
        ArrayList<Coordinates> white_moves = new ArrayList<Coordinates>();
        for(int i = 0; i < 8; i++) {   //collects all possible black and white moves
            for (int j = 0; j < 8; j++) {
                if(!Board[i][j].isEmpty && Board[i][j].piece.charAt(0) == 'b') {
                    black_moves.addAll(Possible_Moves(Board[i][j]));
                }
                if(!Board[i][j].isEmpty && Board[i][j].piece.charAt(0) == 'w') {
                    white_moves.addAll(Possible_Moves(Board[i][j]));
                }
                if(!Board[i][j].isEmpty && Board[i][j].piece.equals("wK")) {
                    wx = j; /** takes down location of kings once traverse*/
                    wy = i;
                }
                if(!Board[i][j].isEmpty && Board[i][j].piece.equals("bK")) {
                    bx = j;
                    by = i;
                }
            }
        }
        /**checks all coordinates in black_moves and white_moves to see if any match
         * coordinates of a king
         * if it does, then that king is in check
         */
        CHECK_ON_WHITE = false; CHECK_ON_BLACK= false;
        for(int i = 0; i < black_moves.size(); i++) {
            if(black_moves.get(i).x == wx && black_moves.get(i).y == wy) {
                CHECK_ON_WHITE = true;
                break;
            }
        }
        for(int i = 0; i < white_moves.size(); i++) {
            if(white_moves.get(i).x == bx && white_moves.get(i).y == by) {
                CHECK_ON_BLACK = true;
                break;
            }
        }
    }

}