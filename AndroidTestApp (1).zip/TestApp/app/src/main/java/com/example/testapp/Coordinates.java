package com.example.testapp;

import java.io.Serializable;

public class Coordinates implements Serializable {

    int x; int y;
    public Coordinates(){

    }
    public Coordinates(int x, int y) {
        this.x = x;
        this.y = y;
    }
    public Coordinates(String position) { //takes input as e4, a3 etc
        char letter = position.charAt(0);
        if (letter == 'a')
            this.x = 0;
        if (letter == 'b')
            this.x = 1;
        if (letter == 'c')
            this.x = 2;
        if (letter == 'd')
            this.x = 3;
        if (letter == 'e')
            this.x = 4;
        if (letter == 'f')
            this.x = 5;
        if (letter == 'g')
            this.x = 6;
        if (letter == 'h')
            this.x = 7;

        this.y = 8 - Character.getNumericValue(position.charAt(1));
    }
    public boolean equals(Coordinates co) {
        if (co.x == this.x && co.y == this.y)
            return true;
        else
            return false;
    }

}


