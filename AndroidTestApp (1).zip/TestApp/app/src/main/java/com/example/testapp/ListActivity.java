package com.example.testapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.content.Intent;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Array;
import java.util.ArrayList;


public class ListActivity extends AppCompatActivity {
    ArrayList<Game> mylist;
    Button exit_button;
    Button play_button;

    ListView mylistview;
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        mylist = new ArrayList<Game>();

        //stock game
        ArrayList<ChessBoard> stock = new ArrayList<ChessBoard>();

        ChessBoard a = new ChessBoard();
        stock.add(a.copy(a));
        a.Move(new Coordinates("e2"), new Coordinates("e4"));
        stock.add(a.copy(a));
        a.Move(new Coordinates("a7"), new Coordinates("a5"));
        stock.add(a.copy(a));
        mylist.add(new Game(stock, "stock", "12/07/2019", "10:43PM"));

        context = getApplicationContext();

        FileInputStream fis = null;
        ObjectInputStream is = null;
        try {
            fis = context.openFileInput("games.txt");
            is = new ObjectInputStream(fis);
            mylist = (ArrayList<Game>) is.readObject();
            is.close();
            fis.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }


        if (getIntent() != null) {
            Intent intent = getIntent();
            if (intent.hasExtra("record") && intent.hasExtra("name")) {
                ArrayList<ChessBoard> newrecord = (ArrayList<ChessBoard>) intent.getSerializableExtra("record");
                String name = (String) intent.getStringExtra("name");

                String date = null;
                String time = null;
                if (intent.hasExtra("date")) {
                    date = (String) intent.getStringExtra("date");
                }
                if (intent.hasExtra("time")) {
                    //set time to obj
                    time = (String) intent.getStringExtra("time");
                }
                mylist.add(new Game(newrecord, name, date, time));
            }
        }
        ListView list = (ListView) findViewById(R.id.games_list);

        ArrayAdapter adapter = new GameAdapter(this, mylist);
        list.setAdapter(adapter);

        exit_button = (Button) findViewById(R.id.button_exitList);
        exit_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                FileOutputStream fos = null;
                ObjectOutputStream os = null;
                try {
                    fos = context.openFileOutput("games.txt", Context.MODE_PRIVATE);
                    os = new ObjectOutputStream(fos);
                    os.writeObject(mylist);
                    os.close();
                    fos.close();
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }

                Intent myIntent = new Intent(ListActivity.this, ModeActivity.class);
                // myIntent.putExtra("key", RECORD); //Optional parameters
                ListActivity.this.startActivity(myIntent);
            }

        });
        mylistview = (ListView) findViewById(R.id.games_list);
        mylistview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
                                    long arg3) {
                Game selectedGame = (Game) arg0.getItemAtPosition(arg2);
                System.out.println("SELECTABLE WORKS" + selectedGame.getName());

                play_button = (Button) findViewById(R.id.button_play_selected);
                play_button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        //transfer to loading screen
                        Intent myIntent = new Intent(ListActivity.this, ReplayActivity.class);
                        myIntent.putExtra("gamerecord", selectedGame.RECORD); //Optional parameters
                        ListActivity.this.startActivity(myIntent);
                    }

                });

            }
        });

    }


}
