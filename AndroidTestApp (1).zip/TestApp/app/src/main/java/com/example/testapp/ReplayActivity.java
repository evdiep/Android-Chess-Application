package com.example.testapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.icu.text.AlphabeticIndex;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.ArrayList;

public class ReplayActivity extends AppCompatActivity {
    private ChessBoard BOARD = new ChessBoard(); //
    private TextView textDisplay;
    private ImageButton[][] buttons = new ImageButton[8][8];
    //declare arraylist of chess board games
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_replay);
        textDisplay = findViewById(R.id.textDisplay);

        textDisplay.setText("Game Playback");
        for (int i = 0; i < 8; i++) {  //saves all the button ids into 8x8 array
            for (int j = 0; j < 8; j++) {
                String buttonID = "button_" + i + j;
                int resID = getResources().getIdentifier(buttonID, "id", getPackageName());
                //System.out.println(resID+"Ffuck" + buttonID);
                buttons[i][j] = findViewById(resID);

            }
        }


        if (getIntent()!=null) {
            Intent intent = getIntent();
            if (intent.hasExtra("gamerecord")){
                ArrayList<ChessBoard> RECORD= (ArrayList<ChessBoard>) intent.getSerializableExtra("gamerecord");
                ImageButton next_button = findViewById(R.id.next);
                next_button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        int i = 1;

                        while (i < RECORD.size()){
                            if(RECORD.get(i)!= null){
                                BOARD = BOARD.copy(RECORD.get(i));
                                RECORD.remove(i);
                                break;
                            }
                            i++;
                        }
                        if(i>=RECORD.size()){
                            Intent myIntent = new Intent(ReplayActivity.this, ModeActivity.class);
                            //myIntent.putExtra("key", RECORD); //Optional parameters
                            ReplayActivity.this.startActivity(myIntent);
                        }
                        BOARD.Analyze();
                        BOARD.Checkmated();
                        refreshBoard();

                    }
                });
            }
        }

    }

        public void refreshBoard() { //traverses through ChessBoard object and updates gui counterparts by
            // changing their image, images follow name pattern where
            // drawable.bpb means black pawn on shaded spot, wKw means white king on white spot

            for(int i=0;i<8;i++){ //promotion
                if (!BOARD.Board[0][i].isEmpty) {
                    if (BOARD.Board[0][i].piece.equals("wp"))
                        BOARD.Board[0][i].piece = "wQ";
                }
                if (!BOARD.Board[7][i].isEmpty) {
                    if (BOARD.Board[7][i].piece.equals("bp"))
                        BOARD.Board[7][i].piece = "bQ";
                }
            }


            for (int i =0; i<8;i++){
                for (int j=0; j<8;j++){

                    if (BOARD.Board[i][j].isEmpty){
                        if(BOARD.Board[i][j].color == 'b')
                            buttons[i][j].setImageResource(R.drawable.blackspace);
                        else
                            buttons[i][j].setImageResource(R.drawable.whitespace);
                    }
                    else{
                        //if not whitespace
                        if(BOARD.Board[i][j].piece.equals("bp")){
                            if (BOARD.Board[i][j].color == 'b')
                                buttons[i][j].setImageResource(R.drawable.bpb);
                            else
                                buttons[i][j].setImageResource(R.drawable.bpw);
                        }
                        if(BOARD.Board[i][j].piece.equals("wp")){
                            if (BOARD.Board[i][j].color == 'b')
                                buttons[i][j].setImageResource(R.drawable.wpb);
                            else
                                buttons[i][j].setImageResource(R.drawable.wpw);
                        }
                        if(BOARD.Board[i][j].piece.equals("wR")){
                            if (BOARD.Board[i][j].color == 'b')
                                buttons[i][j].setImageResource(R.drawable.wrb);
                            else
                                buttons[i][j].setImageResource(R.drawable.wrw);
                        }
                        if(BOARD.Board[i][j].piece.equals("bR")){
                            if (BOARD.Board[i][j].color == 'b')
                                buttons[i][j].setImageResource(R.drawable.brb);
                            else
                                buttons[i][j].setImageResource(R.drawable.brw);
                        }
                        if(BOARD.Board[i][j].piece.equals("wN")){
                            if (BOARD.Board[i][j].color == 'b')
                                buttons[i][j].setImageResource(R.drawable.wnb);
                            else
                                buttons[i][j].setImageResource(R.drawable.wnw);
                        }
                        if(BOARD.Board[i][j].piece.equals("bN")){
                            if (BOARD.Board[i][j].color == 'b')
                                buttons[i][j].setImageResource(R.drawable.bnb);
                            else
                                buttons[i][j].setImageResource(R.drawable.bnw);
                        }
                        if(BOARD.Board[i][j].piece.equals("wB")){
                            if (BOARD.Board[i][j].color == 'b')
                                buttons[i][j].setImageResource(R.drawable.wbb);
                            else
                                buttons[i][j].setImageResource(R.drawable.wbw);
                        }
                        if(BOARD.Board[i][j].piece.equals("bB")){
                            if (BOARD.Board[i][j].color == 'b')
                                buttons[i][j].setImageResource(R.drawable.bbb);
                            else
                                buttons[i][j].setImageResource(R.drawable.bbw);
                        }
                        if(BOARD.Board[i][j].piece.equals("wQ")){
                            if (BOARD.Board[i][j].color == 'b')
                                buttons[i][j].setImageResource(R.drawable.wqb);
                            else
                                buttons[i][j].setImageResource(R.drawable.wqw);
                        }
                        if(BOARD.Board[i][j].piece.equals("bQ")){
                            if (BOARD.Board[i][j].color == 'b')
                                buttons[i][j].setImageResource(R.drawable.bqb);
                            else
                                buttons[i][j].setImageResource(R.drawable.bqw);
                        }
                        if(BOARD.Board[i][j].piece.equals("wK")){
                            if (BOARD.Board[i][j].color == 'b')
                                buttons[i][j].setImageResource(R.drawable.wkb);
                            else
                                buttons[i][j].setImageResource(R.drawable.wkw);
                        }
                        if(BOARD.Board[i][j].piece.equals("bK")){
                            if (BOARD.Board[i][j].color == 'b')
                                buttons[i][j].setImageResource(R.drawable.bkb);
                            else
                                buttons[i][j].setImageResource(R.drawable.bkw);
                        }

                    }
                }
            }

            if (BOARD.CHECKMATE) {
                {
                    if (BOARD.TURN.equals("White's "))
                        textDisplay.setText("Checkmate!: Black wins");
                    else
                        textDisplay.setText("Checkmate!: White wins");
                }
                Intent myIntent = new Intent(ReplayActivity.this, ModeActivity.class);
                //myIntent.putExtra("key", RECORD); //Optional parameters
                ReplayActivity.this.startActivity(myIntent);
            }
         /*  else if (BOARD.TURN == "White's " && BOARD.CHECK_ON_BLACK) {
                textDisplay.setText("Check: Black's Turn");
            }
            else if (BOARD.TURN == "Black's " && BOARD.CHECK_ON_WHITE) {
                textDisplay.setText("Check: White's Turn");
            }
            else {
                textDisplay.setText(BOARD.TURN + " move");
            }*/
        }
    }

